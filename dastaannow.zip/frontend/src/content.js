// ============================================
// DASTAAN LANDING PAGE CONTENT CONFIGURATION
// ============================================
// Edit this file to update all text content and images on the landing page
// No coding knowledge required - just modify the text between quotes

export const CONTENT = {
  brand: {
    name: "Dastaan",
    location: "Hyderabad",
    logo: "https://customer-assets.emergentagent.com/job_dastaan-landing/artifacts/jipj5wpn_IMG_20260218_215732_676.png"
  },

  // ============================================
  // HERO SECTION (First Panel)
  // ============================================
  hero: {
    subtitle: "Be the guest of flavours",
    headline: "Finest tables are hidden in homes.",
    description: "Experience authentic regional dining, hosted by India's best home chefs. Discover, book, and savor unforgettable meals.",
    // Change this URL to update the hero background image
    image: "https://images.unsplash.com/photo-1761092315416-ed229b18e3d6?w=1920&q=80"
  },

  // ============================================
  // VALUE PROPOSITIONS (Scrolling banner)
  // ============================================
  valueProps: [
    "Authentic Flavours",
    "Verified Hosts",
    "Intimate Settings",
    "Cultural Exchange",
    "Ghar Ka Khaana",
    "Curated Experiences"
  ],

  // ============================================
  // HOW IT WORKS SECTION
  // ============================================
  howItWorks: {
    subtitle: "Simple & Seamless",
    title: "How It Works",
    description: "From discovery to your seat at the table, we've made every step effortless.",
    steps: [
      {
        number: "01",
        title: "Discover",
        description: "Browse curated home dining experiences near you. Filter by cuisine, location, and vibe."
      },
      {
        number: "02",
        title: "Book",
        description: "Reserve your seat at the table with secure payments. View menus, photos, and reviews."
      },
      {
        number: "03",
        title: "Experience",
        description: "Arrive as a guest, leave as a friend. Savor authentic flavours and create memories."
      }
    ]
  },

  // ============================================
  // ABOUT DASTAAN SECTION
  // ============================================
  features: {
    subtitle: "Why Dastaan",
    title: "More Than Just a Meal",
    description: "Dastaan is your gateway to authentic Indian home dining experiences. We bridge passionate home chefs with food lovers, bringing centuries-old recipes and warm hospitality from India's kitchens to your table. Each meal is a story, each host a storyteller, and every gathering a celebration of culture, tradition, and connection.",
    
    homeCooked: {
      badge: "Authentic Recipes",
      title: "Home Cooked Magic",
      description: "Experience dishes passed down through generations, prepared with love and tradition.",
      // Change this URL to update the image
      image: "https://images.unsplash.com/photo-1672477179695-7276b0602fa9?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NTY2Nzh8MHwxfHNlYXJjaHwyfHxJbmRpYW4lMjB0aGFsaSUyMG1lYWwlMjB0cmFkaXRpb25hbHxlbnwwfHx8fDE3NzI3MDkwODJ8MA&ixlib=rb-4.1.0&q=85"
    },
    safety: {
      title: "Safety First",
      description: "Verified hosts, hygiene standards, secure payments."
    },
    reviews: {
      title: "Trusted Reviews",
      description: "Real ratings from real diners."
    },
    community: {
      title: "Community",
      description: "Connect over shared meals.",
      // Change this URL to update the image
      image: "https://images.unsplash.com/photo-1768726134345-a8efdcfcc3c6?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjY2NzV8MHwxfHNlYXJjaHwyfHxmcmllbmRzJTIwc2hhcmluZyUyMGZvb2QlMjBsYXVnaGluZyUyMGRpbm5lciUyMHRhYmxlfGVufDB8fHx8MTc3MjcwOTA4M3ww&ixlib=rb-4.1.0&q=85"
    },
    cuisines: {
      title: "Regional Cuisines",
      description: "From Hyderabadi biryani to Bengali mishti."
    }
  },

  // ============================================
  // FOR DINERS SECTION
  // ============================================
  forDiners: {
    subtitle: "For Food Lovers",
    title: "Discover Authentic Home Dining",
    description: "Tired of the same restaurants? Craving the real taste of home? Dastaan connects you with passionate home cooks offering genuine regional cuisine.",
    benefits: [
      "Access to authentic regional cuisine",
      "Warmth and cultural connection",
      "Verified hosts and reviews",
      "Secure online payments",
      "Discover hidden culinary gems"
    ],
    cta: "Find an Experience",
    floatingCard: {
      title: "Ghar Ka Khaana",
      subtitle: "Taste like home"
    },
    // Change this URL to update the image
    image: "https://images.unsplash.com/photo-1736680056361-6a2f6e35fa50?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1NzR8MHwxfHNlYXJjaHwyfHxJbmRpYW4lMjBmb29kJTIwdGhhbGklMjBiaXJ5YW5pJTIwY3Vycnl8ZW58MHx8fHwxNzcyNzA5MDc0fDA&ixlib=rb-4.1.0&q=85"
  },

  // ============================================
  // FOR HOSTS SECTION
  // ============================================
  forHosts: {
    subtitle: "For Home Chefs",
    title: "Turn Your Passion Into a Profession",
    description: "Share your culinary heritage with the world. Join Dastaan as a host and turn your kitchen into a destination for food lovers.",
    benefits: [
      "Monetize your cooking skills",
      "Reach new audiences",
      "Manage bookings easily",
      "Secure upfront payments"
    ],
    stats: {
      hosts: { value: "100+", label: "Happy Hosts" },
      rating: { value: "4.9", label: "Avg. Rating" }
    },
    // Change this URL to update the image
    image: "https://images.unsplash.com/photo-1739963092933-970f66e9398e?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1NzB8MHwxfHNlYXJjaHwzfHxJbmRpYW4lMjB3b21hbiUyMGNvb2tpbmclMjBraXRjaGVufGVufDB8fHx8MTc3MjcwOTA3NXww&ixlib=rb-4.1.0&q=85"
  },

  // ============================================
  // FINAL CTA SECTION
  // ============================================
  finalCta: {
    title: "Ready to Experience Authentic Home Dining?",
    description: "Join thousands discovering the finest home-cooked meals in Hyderabad. Your next unforgettable culinary experience awaits.",
  },

  // Privacy Policy and Terms of Service
  legal: {
    privacyPolicy: {
      title: "Privacy Policy",
      effectiveDate: "Effective Date: January 2025",
      content: `This Privacy Policy describes how Moonlight Technologies LLP, operating the Dastaan platform ("Dastaan", "we", "our", "us"), collects, uses, discloses, processes, and protects your information when you use our mobile application, website, and related services (collectively, the "Platform").

By accessing or using Dastaan, you agree to this Privacy Policy.

**1. INFORMATION WE COLLECT**

We collect information in the following categories:

**1.1 Personal Identification Information**
When you register or use the Platform, we may collect:
• Full name
• Phone number
• Email address
• Profile photo
• Gender (optional)
• Date of birth (optional)

For Hosts:
• Government-issued ID (Aadhaar, PAN, Passport, etc.)
• Address proof
• Bank account details
• Tax information (if applicable)
• FSSAI or other regulatory licenses (if applicable)

**1.2 Contact & Location Information**
• Device location (with consent)
• PIN code
• Residential address (for Hosts)
• IP address
• Device ID
• Device model, OS version

Host home addresses are treated as sensitive personal data and are only shared with confirmed guests per platform rules.

**1.3 Payment & Financial Information**
• Transaction history
• Payment method details (processed by third-party payment gateways)
• Bank account details for host payouts
• We do not store full debit/credit card details. Payment data is processed by compliant third-party providers.

**1.4 Communication Data**
• Messages between Hosts and Guests
• Support queries
• Reviews and ratings
• Uploaded photos
We may monitor communications for safety, fraud prevention, and dispute resolution.

**1.5 Usage & Technical Data**
• App usage patterns
• Click behavior
• Session duration
• Crash logs
• Analytics data

**2. HOW WE USE YOUR INFORMATION**

We process your information for the following purposes:
• To create and manage user accounts
• To verify identity (especially for Hosts)
• To enable bookings and transactions
• To facilitate communication between Hosts and Guests
• To ensure platform safety and trust
• To process payments and payouts
• To prevent fraud, abuse, or illegal activities
• To improve our services
• To comply with legal obligations

We may use aggregated and anonymized data for analytics and business insights.

**3. LEGAL BASIS FOR PROCESSING**

We process personal data on the following lawful bases:
• User consent
• Performance of a contract
• Legal obligation
• Legitimate business interests (such as fraud prevention and service improvement)

**4. INFORMATION SHARING & DISCLOSURE**

We do not sell your personal data.
We may share your information with:

**4.1 Other Users**
• Guest first name and profile photo visible to Hosts
• Host profile, experience details visible publicly
• Host address shared only after confirmed booking

**4.2 Service Providers**
• Payment processors
• KYC verification partners
• Cloud storage providers
• Analytics providers
• Customer support vendors

**4.3 Legal & Regulatory Authorities**
• If required by law, court order, or government authority.

**4.4 Business Transfers**
In case of merger, acquisition, or asset sale.

**5. DATA RETENTION**

We retain personal information:
• As long as your account remains active
• As necessary to comply with legal obligations
• For dispute resolution and fraud prevention
• Users may request account deletion. However, we may retain certain records as required by law.

**6. USER RIGHTS**

Subject to applicable law, you may have the right to:
• Access your personal data
• Correct inaccurate data
• Request deletion
• Withdraw consent
• Object to processing
• Request data portability

To exercise these rights, contact: subhasish.moonlighttechnologies@gmail.com

**7. DATA SECURITY**

We implement reasonable technical and organizational safeguards, including:
• Encryption of sensitive data
• Secure servers
• Access controls
• Masked communication between users
• OTP-based authentication
However, no system is completely secure.

**8. HOST ADDRESS CONFIDENTIALITY**

Host residential addresses are treated as confidential information and:
• Are not publicly displayed
• Are shared only after booking confirmation
• Must not be shared by Guests outside the platform
• Misuse may result in account suspension.

**9. CHILDREN'S PRIVACY**

Dastaan is not intended for individuals under 18 years of age.
We do not knowingly collect data from minors.

**10. THIRD-PARTY LINKS**

The Platform may contain links to third-party websites.
We are not responsible for their privacy practices.

**11. COOKIES & TRACKING**

We may use cookies and similar technologies for:
• Authentication
• Analytics
• Performance tracking
• Marketing optimization
Users can control cookies through device settings.

**12. ACCOUNT DELETION**

Users may delete their account via:
Profile → Settings → Delete Account

Upon deletion:
• Personal profile removed
• Future bookings cancelled
• Legal financial records retained as required

**13. INTERNATIONAL DATA TRANSFER**

If data is stored or processed outside India, we ensure adequate safeguards are in place.

**14. CHANGES TO THIS POLICY**

We may update this Privacy Policy periodically.
Users will be notified of material changes via in-app notification or email.

**15. CONTACT INFORMATION**

For privacy concerns, contact:
Moonlight Technologies LLP
Email: subhasish.moonlighttechnologies@gmail.com`
    },
    termsOfService: {
      title: "Terms of Service",
      effectiveDate: "Effective Date: January 2025",
      content: `Operated by: Moonlight Technologies LLP

**1. INTRODUCTION**

These Terms of Service ("Terms") govern access to and use of the Dastaan mobile application, website, and related services (collectively, the "Platform"), operated by Moonlight Technologies LLP ("Dastaan", "Company", "we", "us", "our").

By using the Platform, you agree to these Terms.
If you do not agree, you must not use the Platform.

**2. NATURE OF THE PLATFORM**

Dastaan is a technology-based SaaS marketplace platform that:
• Connects independent Hosts (home cooks) with Guests
• Facilitates listing, booking, and payment processing
• Provides communication tools

Dastaan:
• Is NOT a restaurant
• Does NOT own, lease, manage, or control any host premises
• Does NOT prepare, handle, or serve food
• Does NOT supervise in-person interactions
• Is NOT responsible for conduct occurring at any host property

Hosts are independent third-party service providers.
Guests and Hosts transact at their own risk.

**3. USER ELIGIBILITY**

• Must be 18 years or older
• Must provide accurate information
• Must comply with local laws
The Company may suspend accounts for violations.

**4. ACCOUNT REGISTRATION**

• Users must register using OTP verification.
• Hosts must complete additional KYC and verification procedures.
• The Company may approve, reject, or revoke host status at its discretion.

**5. HOST AGREEMENT**

By registering as a Host, you agree that:

You are an independent contractor, not an employee or agent of Dastaan.

You are solely responsible for:
• Food preparation
• Hygiene
• Ingredient sourcing
• Guest safety at your premises
• Compliance with food safety laws

You are responsible for:
• Obtaining any required licenses (FSSAI, local permits, etc.)
• Paying applicable taxes

You assume full liability for:
• Food-related illness
• Property damage
• Injury
• Alcohol-related incidents
• Criminal acts occurring at your premises, if any

Dastaan does not inspect or certify kitchens unless explicitly stated.

**6. BOOKING & PAYMENT TERMS**

• Guests pay through the Platform.
• The Company deducts a service/commission fee.
• Remaining amount is remitted to Hosts as payout.
• Payment processing is handled via third-party payment gateways.

Dastaan is not responsible for:
• Bank delays
• Gateway failures
• Incorrect banking details submitted by Hosts

**7. CANCELLATION & REFUND POLICY**

**Guest Cancellations:**
Refund eligibility depends on timing:
• 48+ hours before event: Full refund (excluding platform fee)
• 24-48 hours: Partial refund
• <24 hours: No refund (unless Host cancels)

**Host Cancellations:**
If Host cancels:
• Guest receives full refund
• Repeated host cancellations may lead to suspension
• Refund timelines depend on payment processors.

**8. COMMUNITY GUIDELINES**

Users agree NOT to:
• Engage in harassment or discrimination
• Bring unapproved guests
• Use illegal substances
• Share personal data outside platform
• Record events without consent
• Engage in violence or threatening behavior
Violations may result in permanent suspension.

**9. SAFETY POLICY**

Dastaan may:
• Verify host identities
• Enable masked communication
• Allow ratings and reviews
• Provide reporting mechanisms

However, Dastaan does NOT guarantee safety of:
• Premises
• Food
• Individuals
• Personal belongings
Guests attend events at their own risk.

**10. FOOD SAFETY DISCLAIMER**

Dastaan does not:
• Prepare or inspect food
• Guarantee ingredient quality
• Guarantee allergy compliance
• Guarantee hygiene standards

Hosts are solely responsible for food quality and compliance.
Guests with allergies or medical conditions attend at their own discretion and risk.

**11. CRIMINAL ACTS DISCLAIMER**

Dastaan is a technology intermediary only.

The Company is NOT responsible or liable for:
• Theft
• Assault
• Harassment
• Sexual misconduct
• Drug use
• Alcohol-related incidents
• Property damage
• Any criminal conduct occurring at host premises

Users are responsible for their own actions.
The Company will cooperate with law enforcement when required by law.

**12. DISPUTE RESOLUTION POLICY**

Users agree to:
• Attempt good-faith resolution via platform support first
• Submit disputes within 7 days of event

If unresolved, disputes shall be resolved via:
• Arbitration under the Arbitration and Conciliation Act, 1996 (India)
• Seat of arbitration: Hyderabad
• Language: English
• Courts of Hyderabad shall have exclusive jurisdiction.

**13. LIMITATION OF LIABILITY**

To the maximum extent permitted by law:

Dastaan shall not be liable for:
• Indirect or consequential damages
• Loss of profits
• Personal injury
• Food-related illness
• Property damage
• Emotional distress
• Criminal acts of users

Total liability shall not exceed the service fee paid to Dastaan for the relevant booking.

**14. INDEMNITY**

Users agree to indemnify and hold harmless Dastaan, its directors, employees, and affiliates from:
• Claims arising from food-related issues
• Injury at premises
• User misconduct
• Breach of these Terms
• Regulatory violations by Hosts
• Tax liabilities of Hosts

Hosts specifically indemnify Dastaan against any third-party claims arising from events hosted at their premises.

**15. INTELLECTUAL PROPERTY**

All platform content, branding, design, and technology remain property of the Company.
Users shall not copy, modify, or reverse engineer the platform.

**16. TERMINATION**

The Company may suspend or terminate accounts for:
• Policy violations
• Fraud
• Safety concerns
• Legal risks

**17. TAX DISCLAIMER**

Hosts are solely responsible for:
• Income tax
• GST (if applicable)
• Local regulatory compliance
Dastaan does not provide tax advice.

**18. FORCE MAJEURE**

The Company is not liable for failure due to:
• Natural disasters
• Government restrictions
• Pandemic
• Payment gateway failures
• Internet outages

**19. MODIFICATIONS**

We may update these Terms. Continued use constitutes acceptance.

**20. CONTACT INFORMATION**

Moonlight Technologies LLP
Email: subhasish.moonlighttechnologies@gmail.com, rohit.moonlighttechnologies@gmail.com`
    }
  }
};
