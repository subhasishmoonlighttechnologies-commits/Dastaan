import { useEffect, useRef, useState } from "react";
import "@/App.css";
import {
  Utensils,
  ShieldCheck,
  House,
  Users,
  Heart,
  Star,
  Search,
  Calendar,
  MapPin,
  ArrowRight,
  ChefHat,
  X
} from "lucide-react";
import { CONTENT } from "./content";

function App() {
  const heroRef = useRef(null);
  const scrollIndicatorRef = useRef(null);
  const [showModal, setShowModal] = useState(false);
  const [modalContent, setModalContent] = useState(null);

  useEffect(() => {
    // Scroll animations
    const observerOptions = {
      threshold: 0.1,
      rootMargin: "0px 0px -100px 0px"
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = "1";
          entry.target.style.transform = "translateY(0)";
        }
      });
    }, observerOptions);

    const elements = document.querySelectorAll('[data-animate]');
    elements.forEach(el => observer.observe(el));

    // Scroll indicator animation
    if (scrollIndicatorRef.current) {
      const animate = () => {
        const scrollY = window.scrollY;
        if (scrollIndicatorRef.current) {
          scrollIndicatorRef.current.style.opacity = scrollY > 100 ? "0" : "1";
        }
      };
      window.addEventListener('scroll', animate);
      return () => window.removeEventListener('scroll', animate);
    }

    return () => observer.disconnect();
  }, []);

  const openModal = (type) => {
    setModalContent(type === 'privacy' ? CONTENT.legal.privacyPolicy : CONTENT.legal.termsOfService);
    setShowModal(true);
    document.body.style.overflow = 'hidden';
  };

  const closeModal = () => {
    setShowModal(false);
    setModalContent(null);
    document.body.style.overflow = 'unset';
  };

  const valuePropIcons = [Utensils, ShieldCheck, House, Users, Heart, Star];

  return (
    <div className="min-h-screen bg-brand-cream">
      {/* Hero Section */}
      <section 
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
        data-testid="hero-section"
      >
        <div className="absolute inset-0 z-0">
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `url("${CONTENT.hero.image}")`
            }}
          />
          {/* Dark overlay for text readability - no white gradient */}
          <div className="absolute inset-0 bg-black/40" />
        </div>

        <div className="relative z-10 text-center px-4 md:px-8 max-w-5xl mx-auto pt-24" data-animate>
          {/* Dastaan Logo - Extra Large for Better Balance */}
          <div className="mb-10 flex justify-center">
            <img 
              src={CONTENT.brand.logo} 
              alt="Dastaan Logo" 
              className="h-48 md:h-64 lg:h-80 w-auto drop-shadow-[0_6px_20px_rgba(0,0,0,0.95)]"
              data-testid="dastaan-logo"
            />
          </div>
          
          <p className="text-white font-bold text-sm md:text-base tracking-widest uppercase mb-6 drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]" data-testid="hero-tagline">
            {CONTENT.hero.subtitle}
          </p>
          <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-bold text-white leading-tight mb-6 drop-shadow-[0_4px_12px_rgba(0,0,0,0.9)]" data-testid="hero-headline">
            {CONTENT.hero.headline}
          </h1>
          <p className="text-white text-lg md:text-xl max-w-2xl mx-auto mb-10 font-medium drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]" data-testid="hero-subheadline">
            {CONTENT.hero.description}
          </p>
          {/* Removed Explore Experiences button as requested */}
          <div className="mt-12 inline-flex items-center gap-2 bg-white/80 backdrop-blur-md border-2 border-brand-mint rounded-full px-6 py-3 shadow-lg" data-testid="location-badge">
            <MapPin className="w-5 h-5 text-brand-mint" />
            <span className="text-brand-charcoal text-sm font-semibold">
              Currently live in <span className="text-brand-coral">{CONTENT.brand.location}</span>
            </span>
          </div>
        </div>

        <div ref={scrollIndicatorRef} className="absolute bottom-8 left-1/2 -translate-x-1/2">
          <div className="w-6 h-10 border-2 border-brand-coral/50 rounded-full flex justify-center p-2">
            <div className="w-1 h-1 bg-brand-coral rounded-full animate-bounce" />
          </div>
        </div>
      </section>

      {/* Value Props Marquee */}
      <section className="py-8 bg-gradient-to-r from-brand-coral via-brand-yellow to-brand-mint border-y-4 border-brand-mint overflow-hidden" data-testid="value-props-section">
        <div className="flex animate-marquee">
          {[...CONTENT.valueProps, ...CONTENT.valueProps].map((text, index) => {
            const IconComponent = valuePropIcons[index % valuePropIcons.length];
            return (
              <div key={index} className="flex items-center gap-3 px-8 whitespace-nowrap">
                <IconComponent className="w-5 h-5 text-white" />
                <span className="text-white font-bold text-lg">{text}</span>
                <span className="text-white/70">•</span>
              </div>
            );
          })}
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-24 md:py-32 px-4 md:px-8 bg-gradient-to-b from-brand-cream to-brand-peach" data-testid="how-it-works-section">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16" data-animate>
            <p className="text-brand-mint font-bold text-sm tracking-widest uppercase mb-4">
              {CONTENT.howItWorks.subtitle}
            </p>
            <h2 className="font-serif text-5xl md:text-6xl font-bold text-brand-charcoal mb-4" data-testid="how-it-works-title">
              {CONTENT.howItWorks.title}
            </h2>
            <p className="text-brand-charcoal/70 text-lg max-w-2xl mx-auto">
              {CONTENT.howItWorks.description}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {CONTENT.howItWorks.steps.map((step, index) => {
              const icons = [Search, Calendar, Heart];
              const IconComponent = icons[index];
              const bgColors = ['bg-brand-pink', 'bg-brand-lavender', 'bg-brand-sage'];
              const borderColors = ['border-brand-coral', 'border-brand-mint', 'border-brand-yellow'];
              
              return (
                <div 
                  key={index}
                  className={`${bgColors[index]} border-4 ${borderColors[index]} p-8 rounded-3xl hover:scale-105 transition-all duration-500 group relative overflow-hidden shadow-xl`}
                  data-testid={`step-${index + 1}`}
                  data-animate
                >
                  <span className="text-brand-coral/20 font-serif text-7xl font-bold absolute top-4 right-6">
                    {step.number}
                  </span>
                  <div className="relative z-10">
                    <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                      <IconComponent className="w-8 h-8 text-brand-coral" />
                    </div>
                    <h3 className="font-serif text-3xl font-bold text-brand-charcoal mb-3">{step.title}</h3>
                    <p className="text-brand-charcoal/80 leading-relaxed font-medium">{step.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section (About Dastaan) */}
      <section id="experiences" className="py-24 md:py-32 px-4 md:px-8 bg-white" data-testid="features-section">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16" data-animate>
            <p className="text-brand-coral font-bold text-sm tracking-widest uppercase mb-4">
              {CONTENT.features.subtitle}
            </p>
            <h2 className="font-serif text-5xl md:text-6xl font-bold text-brand-charcoal mb-6" data-testid="features-title">
              {CONTENT.features.title}
            </h2>
            <p className="text-brand-charcoal/70 text-lg leading-relaxed max-w-3xl mx-auto font-medium">
              {CONTENT.features.description}
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-4 auto-rows-[200px]">
            {/* Home Cooked Magic - Large Card */}
            <div className="md:col-span-2 md:row-span-2 relative overflow-hidden rounded-3xl group border-4 border-brand-yellow shadow-xl" data-testid="feature-home-cooked" data-animate>
              <img 
                src={CONTENT.features.homeCooked.image}
                alt="Home cooked food"
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-coral/90 via-brand-coral/40 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-8">
                <div className="flex items-center gap-2 mb-3 bg-white/90 rounded-full px-4 py-2 inline-flex">
                  <ChefHat className="w-5 h-5 text-brand-coral" />
                  <span className="text-brand-charcoal text-sm font-bold">{CONTENT.features.homeCooked.badge}</span>
                </div>
                <h3 className="font-serif text-4xl font-bold text-white mb-2">{CONTENT.features.homeCooked.title}</h3>
                <p className="text-white/90 text-base font-medium">{CONTENT.features.homeCooked.description}</p>
              </div>
            </div>

            {/* Safety First */}
            <div className="bg-brand-lavender border-4 border-brand-mint rounded-3xl p-6 flex flex-col justify-between hover:scale-105 transition-all shadow-xl" data-testid="feature-safety" data-animate>
              <ShieldCheck className="w-12 h-12 text-brand-mint" />
              <div>
                <h3 className="font-serif text-2xl font-bold text-brand-charcoal mb-1">{CONTENT.features.safety.title}</h3>
                <p className="text-brand-charcoal/70 text-sm font-medium">{CONTENT.features.safety.description}</p>
              </div>
            </div>

            {/* Trusted Reviews */}
            <div className="bg-brand-yellow border-4 border-brand-coral rounded-3xl p-6 flex flex-col justify-between hover:scale-105 transition-all shadow-xl" data-testid="feature-ratings" data-animate>
              <Star className="w-12 h-12 text-brand-coral fill-brand-coral" />
              <div>
                <h3 className="font-serif text-2xl font-bold text-brand-charcoal mb-1">{CONTENT.features.reviews.title}</h3>
                <p className="text-brand-charcoal/70 text-sm font-medium">{CONTENT.features.reviews.description}</p>
              </div>
            </div>

            {/* Community - Image Card */}
            <div className="md:row-span-2 relative overflow-hidden rounded-3xl group border-4 border-brand-mint shadow-xl" data-testid="feature-community" data-animate>
              <img 
                src={CONTENT.features.community.image}
                alt="Community dining"
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-mint/90 via-brand-mint/30 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <Users className="w-10 h-10 text-white mb-3" />
                <h3 className="font-serif text-3xl font-bold text-white mb-1">{CONTENT.features.community.title}</h3>
                <p className="text-white/90 text-sm font-medium">{CONTENT.features.community.description}</p>
              </div>
            </div>

            {/* Regional Cuisines */}
            <div className="bg-brand-sage border-4 border-brand-yellow rounded-3xl p-6 flex flex-col justify-between hover:scale-105 transition-all shadow-xl" data-testid="feature-cuisines" data-animate>
              <Utensils className="w-12 h-12 text-brand-charcoal" />
              <div>
                <h3 className="font-serif text-2xl font-bold text-brand-charcoal mb-1">{CONTENT.features.cuisines.title}</h3>
                <p className="text-brand-charcoal/70 text-sm font-medium">{CONTENT.features.cuisines.description}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* For Diners */}
      <section className="py-24 md:py-32 px-4 md:px-8 bg-gradient-to-br from-brand-peach to-brand-pink" data-testid="for-diners-section">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative" data-animate>
              <div className="relative rounded-3xl overflow-hidden aspect-[4/3] border-4 border-brand-coral shadow-2xl">
                <img 
                  src={CONTENT.forDiners.image}
                  alt="Delicious home cooked meal"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-brand-coral/30 to-transparent" />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-white border-4 border-brand-mint rounded-2xl p-5 shadow-2xl">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 bg-brand-coral rounded-full flex items-center justify-center">
                    <Heart className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <p className="text-brand-charcoal font-bold text-lg">{CONTENT.forDiners.floatingCard.title}</p>
                    <p className="text-brand-coral text-sm font-medium">{CONTENT.forDiners.floatingCard.subtitle}</p>
                  </div>
                </div>
              </div>
            </div>

            <div data-animate>
              <p className="text-brand-mint font-bold text-sm tracking-widest uppercase mb-4">
                {CONTENT.forDiners.subtitle}
              </p>
              <h2 className="font-serif text-5xl md:text-6xl font-bold text-brand-charcoal mb-6" data-testid="for-diners-title">
                {CONTENT.forDiners.title}
              </h2>
              <p className="text-brand-charcoal/70 text-lg mb-8 font-medium">
                {CONTENT.forDiners.description}
              </p>
              <ul className="space-y-4 mb-8">
                {CONTENT.forDiners.benefits.map((benefit, index) => (
                  <li key={index} className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-brand-mint flex items-center justify-center flex-shrink-0">
                      <div className="w-3 h-3 rounded-full bg-white" />
                    </div>
                    <span className="text-brand-charcoal font-medium">{benefit}</span>
                  </li>
                ))}
              </ul>
              {/* Removed Find an Experience button as requested */}
            </div>
          </div>
        </div>
      </section>

      {/* For Hosts */}
      <section id="about" className="py-24 md:py-32 px-4 md:px-8 relative overflow-hidden bg-white" data-testid="host-info-section">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-lavender/30 via-transparent to-brand-sage/30" />
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div data-animate>
              <p className="text-brand-coral font-bold text-sm tracking-widest uppercase mb-4">
                {CONTENT.forHosts.subtitle}
              </p>
              <h2 className="font-serif text-5xl md:text-6xl font-bold text-brand-charcoal mb-6" data-testid="host-info-title">
                {CONTENT.forHosts.title}
              </h2>
              <p className="text-brand-charcoal/70 text-lg mb-8 font-medium">
                {CONTENT.forHosts.description}
              </p>
              <div className="grid sm:grid-cols-2 gap-4">
                {CONTENT.forHosts.benefits.map((benefit, index) => {
                  const icons = [ChefHat, Users, Calendar, ShieldCheck];
                  const IconComponent = icons[index];
                  const bgColors = ['bg-brand-pink', 'bg-brand-lavender', 'bg-brand-sage', 'bg-brand-yellow'];
                  
                  return (
                    <div key={index} className={`flex items-center gap-3 ${bgColors[index]} border-2 border-brand-charcoal/10 rounded-2xl px-4 py-3 shadow-lg hover:scale-105 transition-all`}>
                      <IconComponent className="w-6 h-6 text-brand-coral flex-shrink-0" />
                      <span className="text-brand-charcoal text-sm font-bold">{benefit}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="relative" data-animate>
              <div className="relative rounded-3xl overflow-hidden aspect-square max-w-md mx-auto border-4 border-brand-mint shadow-2xl">
                <img 
                  src={CONTENT.forHosts.image}
                  alt="Host preparing food"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-brand-mint/40 to-transparent" />
              </div>
              
              <div className="absolute -top-4 -left-4 bg-white border-4 border-brand-coral rounded-2xl p-5 shadow-2xl">
                <p className="text-4xl font-bold text-brand-coral">{CONTENT.forHosts.stats.hosts.value}</p>
                <p className="text-brand-charcoal/70 text-sm font-bold">{CONTENT.forHosts.stats.hosts.label}</p>
              </div>
              
              <div className="absolute -bottom-4 -right-4 bg-white border-4 border-brand-yellow rounded-2xl p-5 shadow-2xl">
                <p className="text-4xl font-bold text-brand-yellow">{CONTENT.forHosts.stats.rating.value}</p>
                <p className="text-brand-charcoal/70 text-sm font-bold">{CONTENT.forHosts.stats.rating.label}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 md:py-32 px-4 md:px-8 bg-gradient-to-br from-brand-coral via-brand-yellow to-brand-mint" data-testid="final-cta-section">
        <div className="max-w-4xl mx-auto text-center" data-animate>
          <h2 className="font-serif text-5xl md:text-7xl font-bold text-white mb-6 drop-shadow-lg" data-testid="final-cta-title">
            {CONTENT.finalCta.title}
          </h2>
          <p className="text-white text-lg md:text-xl mb-10 max-w-2xl mx-auto font-medium drop-shadow">
            {CONTENT.finalCta.description}
          </p>
          {/* Removed Explore Experiences button as requested */}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 bg-brand-charcoal text-white text-center">
        <p className="text-sm mb-4">© 2026 {CONTENT.brand.name}. Made with ❤️ in {CONTENT.brand.location}</p>
        <div className="flex justify-center gap-6 text-sm">
          <button 
            onClick={() => openModal('privacy')}
            className="text-white/70 hover:text-brand-coral transition-colors underline cursor-pointer"
            data-testid="privacy-policy-link"
          >
            Privacy Policy
          </button>
          <span className="text-white/30">|</span>
          <button 
            onClick={() => openModal('terms')}
            className="text-white/70 hover:text-brand-coral transition-colors underline cursor-pointer"
            data-testid="terms-of-service-link"
          >
            Terms of Service
          </button>
        </div>
      </footer>

      {/* Legal Modal */}
      {showModal && modalContent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={closeModal}>
          <div 
            className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
            data-testid="legal-modal"
          >
            {/* Modal Header */}
            <div className="sticky top-0 bg-brand-coral px-6 py-4 flex items-center justify-between border-b-4 border-brand-yellow">
              <div>
                <h2 className="text-2xl font-bold text-white">{modalContent.title}</h2>
                <p className="text-white/80 text-sm">{modalContent.effectiveDate}</p>
              </div>
              <button 
                onClick={closeModal}
                className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-colors"
                data-testid="close-modal-btn"
              >
                <X className="w-6 h-6 text-white" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-100px)] prose prose-sm max-w-none">
              <div className="text-brand-charcoal whitespace-pre-wrap leading-relaxed">
                {modalContent.content.split('\n\n').map((paragraph, index) => (
                  <p key={index} className="mb-4">
                    {paragraph.split('\n').map((line, lineIndex) => (
                      <span key={lineIndex}>
                        {line.startsWith('**') && line.endsWith('**') ? (
                          <strong className="text-brand-coral block mt-4 mb-2 text-lg">
                            {line.replace(/\*\*/g, '')}
                          </strong>
                        ) : line.startsWith('•') ? (
                          <span className="block ml-4 my-1">
                            <span className="text-brand-mint mr-2">•</span>
                            {line.substring(1).trim()}
                          </span>
                        ) : (
                          line
                        )}
                        {lineIndex < paragraph.split('\n').length - 1 && <br />}
                      </span>
                    ))}
                  </p>
                ))}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="sticky bottom-0 bg-brand-peach px-6 py-4 border-t-2 border-brand-coral/20">
              <button 
                onClick={closeModal}
                className="bg-brand-coral hover:bg-brand-charcoal text-white font-bold px-8 py-3 rounded-full transition-colors w-full md:w-auto"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
