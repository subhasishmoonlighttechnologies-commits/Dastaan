# 🎨 DASTAAN LANDING PAGE - CONTENT EDITING GUIDE

## 📝 How to Edit Content

All text content and images can be edited without any coding knowledge!

### 📍 Where to Edit

**File Location:** `/app/frontend/src/content.js`

This single file contains ALL the content on your landing page.

---

## 🖼️ How to Change Images

### Step 1: Find the image you want to change
In `content.js`, look for lines with `image:` followed by a URL.

### Step 2: Replace the URL
Simply replace the URL between the quotes with your new image URL.

**Example:**
```javascript
// Before
image: "https://images.unsplash.com/photo-old-image.jpg"

// After  
image: "https://your-new-image-url.jpg"
```

### Images You Can Change:
1. **Hero Image** (First panel background) - Line ~29
2. **Home Cooked Magic** (Large food card) - Line ~67
3. **Community** (People dining together) - Line ~77
4. **For Diners** (Food image) - Line ~97
5. **For Hosts** (Host cooking image) - Line ~119

---

## ✏️ How to Change Text

### Headlines
Find the section you want to edit and change the text between quotes:

```javascript
// Hero headline
headline: "Finest tables are hidden in homes.",

// To change it:
headline: "Your new headline here",
```

### Descriptions
Same process - just replace the text:

```javascript
description: "Your new description text goes here.",
```

### Buttons
Button text can also be changed:

```javascript
primaryCta: "Explore Experiences",  // Change button text here
```

---

## 📋 Content Sections Reference

### 1. **Hero Section** (Lines 12-30)
- `subtitle` - Small text above headline
- `headline` - Main big text
- `description` - Paragraph below headline
- `image` - Background image URL

### 2. **Value Props** (Lines 36-43)
- Array of short phrases shown in the scrolling banner

### 3. **How It Works** (Lines 49-67)
- Three steps with titles and descriptions

### 4. **About Dastaan / Why Dastaan** (Lines 73-94)
- Main description paragraph
- Four feature cards with titles and descriptions

### 5. **For Diners** (Lines 100-112)
- Title, description, and 5 benefits list

### 6. **For Hosts** (Lines 118-132)
- Title, description, 4 benefits, and statistics

### 7. **Final CTA** (Lines 138-142)
- Final call-to-action text

---

## 🚀 After Making Changes

1. **Save the file**
2. **Refresh your browser** - Changes should appear automatically!
3. If changes don't show, try a hard refresh:
   - **Windows/Linux:** `Ctrl + Shift + R`
   - **Mac:** `Cmd + Shift + R`

---

## ⚠️ Important Rules

### DO:
✅ Change text between quotes `"like this"`  
✅ Replace image URLs  
✅ Add or remove items from lists (like benefits)  
✅ Change numbers and statistics  

### DON'T:
❌ Delete commas (`,`)  
❌ Delete colons (`:`)  
❌ Delete quotes (`"`)  
❌ Delete brackets (`[]` or `{}`)  
❌ Change variable names (like `headline:`, `image:`, etc.)  

---

## 🎨 Color Scheme

The landing page uses a fresh, pastel, poppy color palette:

- **Coral Pink** (#FF6B6B) - Main accent color
- **Mint Green** (#4ECDC4) - Secondary accent
- **Sunny Yellow** (#FFD93D) - Bright highlights
- **Soft Peach** (#FFE5D9) - Light backgrounds
- **Lavender Blue** (#A8DADC) - Soft accents
- **Warm Cream** (#FEF9F3) - Main background

To change colors, edit `/app/frontend/tailwind.config.js` (requires technical knowledge).

---

## 🆘 Need Help?

If you accidentally break something:

1. **Undo your changes** (Ctrl+Z / Cmd+Z)
2. **Check for missing commas or quotes**
3. **Compare with the original format**

---

## 📞 Support

For technical issues with editing, contact your development team.

Happy editing! 🎉
