# 🎨 DASTAAN LANDING PAGE - CONTENT REFERENCE

## Quick Reference for All Editable Content

File: `/app/frontend/src/content.js`

---

## 🏠 HERO SECTION (First Panel)

**Location in file:** Lines 12-30

```javascript
hero: {
  subtitle: "Be the guest of flavours",           // Small text above headline
  headline: "Finest tables are hidden in homes.",  // Main large text
  description: "Experience authentic...",          // Paragraph text
  image: "https://images.unsplash.com/..."         // Background image URL
}
```

**What to edit:**
- Tagline (subtitle)
- Main headline
- Description paragraph
- Background image

---

## 🎯 VALUE PROPOSITIONS (Scrolling Banner)

**Location in file:** Lines 36-43

```javascript
valueProps: [
  "Authentic Flavours",
  "Verified Hosts",
  "Intimate Settings",
  "Cultural Exchange",
  "Ghar Ka Khaana",
  "Curated Experiences"
]
```

**To add more:**
```javascript
valueProps: [
  "Authentic Flavours",
  "Your New Value",  // ← Add here
  "Another One",     // ← Or here
]
```

---

## 📋 HOW IT WORKS

**Location in file:** Lines 49-67

```javascript
howItWorks: {
  subtitle: "Simple & Seamless",
  title: "How It Works",
  description: "From discovery to your seat...",
  steps: [
    {
      number: "01",
      title: "Discover",
      description: "Browse curated..."
    },
    // ... more steps
  ]
}
```

**To edit a step:**
1. Find the step number
2. Change title or description
3. Save

---

## ℹ️ ABOUT DASTAAN / WHY DASTAAN

**Location in file:** Lines 73-94

```javascript
features: {
  subtitle: "Why Dastaan",
  title: "More Than Just a Meal",
  description: "Dastaan is your gateway...",  // ← Main about paragraph
  
  homeCooked: {
    title: "Home Cooked Magic",
    description: "Experience dishes...",
    image: "https://..."  // ← Large food image
  },
  
  safety: {
    title: "Safety First",
    description: "Verified hosts..."
  },
  // ... more features
}
```

**Main about text:** Line ~75

---

## 🍽️ FOR DINERS SECTION

**Location in file:** Lines 100-112

```javascript
forDiners: {
  subtitle: "For Food Lovers",
  title: "Discover Authentic Home Dining",
  description: "Tired of the same restaurants?...",
  benefits: [
    "Access to authentic regional cuisine",
    "Warmth and cultural connection",
    "Verified hosts and reviews",
    "Secure online payments",
    "Discover hidden culinary gems"
  ],
  image: "https://..."  // Food image
}
```

**To add/remove benefits:**
```javascript
benefits: [
  "Benefit 1",
  "Benefit 2",
  "New Benefit",  // ← Add here
]
```

---

## 👨‍🍳 FOR HOSTS SECTION

**Location in file:** Lines 118-132

```javascript
forHosts: {
  subtitle: "For Home Chefs",
  title: "Turn Your Passion Into a Profession",
  description: "Share your culinary heritage...",
  benefits: [
    "Monetize your cooking skills",
    "Reach new audiences",
    "Manage bookings easily",
    "Secure upfront payments"
  ],
  stats: {
    hosts: { 
      value: "100+",      // ← Change number
      label: "Happy Hosts" 
    },
    rating: { 
      value: "4.9",       // ← Change rating
      label: "Avg. Rating" 
    }
  },
  image: "https://..."  // Host cooking image
}
```

---

## 🎉 FINAL CTA SECTION

**Location in file:** Lines 138-142

```javascript
finalCta: {
  title: "Ready to Experience Authentic Home Dining?",
  description: "Join thousands discovering...",
}
```

---

## 🎨 COLOR CUSTOMIZATION

File: `/app/frontend/tailwind.config.js`

**All colors (Lines 6-14):**

```javascript
colors: {
  'brand-coral': '#FF6B6B',      // Buttons, accents
  'brand-peach': '#FFE5D9',      // Light backgrounds
  'brand-mint': '#4ECDC4',       // Badges, borders
  'brand-lavender': '#A8DADC',   // Card backgrounds
  'brand-cream': '#FEF9F3',      // Main background
  'brand-yellow': '#FFD93D',     // Highlights
  'brand-pink': '#FFB6C1',       // Card backgrounds
  'brand-charcoal': '#2D3142',   // Text
  'brand-sage': '#B8E6B8',       // Card backgrounds
}
```

**To change brand color:**
1. Pick a new hex code (e.g., from coolors.co)
2. Replace the value
3. Save → Color updates everywhere!

---

## 📍 BRAND INFO

**Location in file:** Lines 12-15

```javascript
brand: {
  name: "Dastaan",      // ← Brand name
  location: "Hyderabad" // ← City
}
```

---

## 🔗 QUICK FIND

**Use Ctrl+F / Cmd+F to search for:**

- `hero` → First panel
- `howItWorks` → How It Works section
- `features` → About Dastaan
- `forDiners` → For Food Lovers
- `forHosts` → For Home Chefs
- `finalCta` → Last section
- `image:` → All images
- `description:` → All descriptions

---

## 💡 TIPS

1. **Keep text concise** - Shorter is better for readability
2. **Use high-res images** - Minimum 1200px wide
3. **Test on mobile** - Check how it looks on phone
4. **Backup before major changes** - Copy the file first
5. **Change one thing at a time** - Easier to track what works

---

**Happy editing! You have full control.** 🎉
