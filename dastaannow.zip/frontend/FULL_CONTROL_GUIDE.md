# 🎨 DASTAAN LANDING PAGE - COMPLETE CONTROL GUIDE

## 📋 QUICK START

Your team has **COMPLETE CONTROL** over:
- ✏️ All text content
- 🖼️ All images
- 🎨 All colors
- 📐 Layout and sections
- 🔘 Buttons and links

---

## 📂 FILE STRUCTURE

```
/app/frontend/
├── src/
│   ├── content.js          ← ⭐ EDIT THIS for all text & images
│   ├── App.js              ← Main page structure
│   ├── App.css             ← Custom styles
│   └── index.css           ← Global styles
├── tailwind.config.js      ← ⭐ EDIT THIS for colors
└── CONTENT_EDITING_GUIDE.md ← Basic editing guide
```

---

## 🎯 WHAT CONTROLS WHAT

### 1️⃣ **ALL TEXT & IMAGES** → `/app/frontend/src/content.js`

**What you can edit:**
- Every headline, subtitle, description
- All button text
- Image URLs
- Location, brand name
- Benefits lists, statistics

**Example changes:**
```javascript
// Change hero headline
headline: "Your new headline here",

// Change hero image
image: "https://your-new-image-url.jpg",

// Change location
location: "Mumbai",
```

### 2️⃣ **ALL COLORS** → `/app/frontend/tailwind.config.js`

**Current color palette:**
```javascript
'brand-coral': '#FF6B6B',      // Main pink
'brand-mint': '#4ECDC4',       // Teal/mint
'brand-yellow': '#FFD93D',     // Bright yellow
'brand-peach': '#FFE5D9',      // Light peach
'brand-lavender': '#A8DADC',   // Soft blue
'brand-cream': '#FEF9F3',      // Background
'brand-pink': '#FFB6C1',       // Soft pink
'brand-sage': '#B8E6B8',       // Green
'brand-charcoal': '#2D3142',   // Dark text
```

**To change colors:**
1. Find the color name (e.g., `brand-coral`)
2. Replace the hex code (e.g., `#FF6B6B`)
3. Save file → Page updates automatically

### 3️⃣ **PAGE STRUCTURE** → `/app/frontend/src/App.js`

**What's in this file:**
- Section order
- Layout structure
- Components arrangement
- Animations

**When to edit:**
- Add/remove entire sections
- Change section order
- Modify layouts
- Add new features

---

## 📝 HOW TO EDIT CONTENT

### Method 1: Direct File Editing (Recommended)

1. **Open the file:**
   - Navigate to `/app/frontend/src/content.js`
   - Open in any text editor

2. **Find what you want to change:**
   - Use Ctrl+F (Windows) or Cmd+F (Mac) to search
   - Look for section names: `hero`, `howItWorks`, `features`, etc.

3. **Make your changes:**
   ```javascript
   // Example: Change hero subtitle
   subtitle: "New tagline here",
   
   // Example: Change description
   description: "Your new description text.",
   
   // Example: Update image
   image: "https://new-image-url.com/image.jpg",
   ```

4. **Save the file**
   - Changes appear automatically in browser
   - If not, refresh with Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)

### Method 2: Using Code Editor (VS Code, etc.)

1. Open the project folder in your code editor
2. Navigate to the file you want to edit
3. Make changes and save
4. See changes live in browser

---

## 🖼️ HOW TO CHANGE IMAGES

### Step 1: Upload Your Image

Option A: Use an image hosting service
- Upload to: Imgur, Cloudinary, AWS S3, or your own server
- Copy the direct image URL

Option B: Use Unsplash (free high-quality images)
- Go to unsplash.com
- Find an image
- Right-click → Copy Image Address

### Step 2: Update content.js

```javascript
// Find the image you want to change
image: "OLD_URL_HERE",

// Replace with new URL
image: "https://your-new-image-url.jpg",
```

### Images You Can Change:

1. **Hero Background** (Line ~29)
   ```javascript
   hero: {
     image: "URL_HERE"
   }
   ```

2. **Home Cooked Magic** (Line ~67)
   ```javascript
   homeCooked: {
     image: "URL_HERE"
   }
   ```

3. **Community Section** (Line ~77)
   ```javascript
   community: {
     image: "URL_HERE"
   }
   ```

4. **For Diners** (Line ~97)
   ```javascript
   forDiners: {
     image: "URL_HERE"
   }
   ```

5. **For Hosts** (Line ~119)
   ```javascript
   forHosts: {
     image: "URL_HERE"
   }
   ```

---

## 🎨 HOW TO CHANGE COLORS

### Edit: `/app/frontend/tailwind.config.js`

```javascript
colors: {
  'brand-coral': '#FF6B6B',  // ← Change this hex code
  'brand-mint': '#4ECDC4',   // ← Change this hex code
  // ... etc
}
```

### Color Usage Map:

| Color | Where It's Used |
|-------|----------------|
| `brand-coral` | Hero tagline, buttons, accents |
| `brand-mint` | Location badge, step cards, borders |
| `brand-yellow` | Step cards, borders, stat badges |
| `brand-peach` | Section backgrounds |
| `brand-lavender` | Card backgrounds |
| `brand-cream` | Main page background |
| `brand-pink` | Card backgrounds, gradients |
| `brand-sage` | Card backgrounds |
| `brand-charcoal` | Text color, footer |

### Example: Change Main Accent Color

```javascript
// Before (coral pink)
'brand-coral': '#FF6B6B',

// After (purple)
'brand-coral': '#9B59B6',
```

---

## ➕ HOW TO ADD/REMOVE SECTIONS

### To Remove a Section:

1. Open `/app/frontend/src/App.js`
2. Find the section (e.g., `<section id="how-it-works"`)
3. Delete the entire `<section>...</section>` block
4. Save

### To Add a New Section:

1. Copy an existing section as template
2. Paste it where you want the new section
3. Update the content
4. Save

---

## 🔗 HOW TO CHANGE BUTTONS/LINKS

### Buttons are in: `/app/frontend/src/App.js`

Search for `<button` to find all buttons.

**To add functionality:**

```javascript
// Before (no action)
<button className="...">
  Button Text
</button>

// After (with link)
<button 
  className="..."
  onClick={() => window.location.href = 'https://your-link.com'}
>
  Button Text
</button>

// Or use <a> tag for links
<a 
  href="https://your-link.com"
  className="..."
>
  Button Text
</a>
```

---

## 📱 HOW TO TEST CHANGES

### Method 1: Browser (Quick)
1. Save your changes
2. Go to: https://dastaan-landing.preview.emergentagent.com
3. Refresh page (Ctrl+Shift+R or Cmd+Shift+R)

### Method 2: Multiple Devices
1. Open on phone/tablet
2. Use the same URL
3. Check responsive design

---

## 🚨 COMMON ISSUES & FIXES

### Issue 1: Changes Not Showing

**Solution:**
1. Hard refresh: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)
2. Clear browser cache
3. Try incognito/private mode

### Issue 2: Page is Blank/Broken

**Solution:**
1. Check for missing commas in content.js
2. Check for missing quotes
3. Undo your last change
4. Look at browser console (F12) for errors

### Issue 3: Image Not Loading

**Solution:**
1. Verify image URL works (paste in browser)
2. Make sure URL starts with `http://` or `https://`
3. Check image format (JPG, PNG, WEBP work best)
4. Try a different image URL

---

## ✅ BEST PRACTICES

### DO:
✅ Make one change at a time
✅ Test after each change
✅ Keep backup of original files
✅ Use high-quality images (min 1200px wide)
✅ Use descriptive file names
✅ Keep text concise and scannable

### DON'T:
❌ Delete commas, brackets, or quotes
❌ Change variable names (e.g., `headline:`, `image:`)
❌ Use very large images (> 5MB)
❌ Delete entire sections from content.js
❌ Change file structure

---

## 🎯 QUICK EDITS CHECKLIST

Common things your team might want to edit:

- [ ] Hero headline
- [ ] Hero image
- [ ] Location (Hyderabad)
- [ ] About Dastaan paragraph
- [ ] Host statistics (100+, 4.9)
- [ ] Benefits lists
- [ ] Contact email/phone
- [ ] Social media links
- [ ] Footer text

---

## 📞 NEED HELP?

### For Technical Issues:
1. Check the console (F12 in browser)
2. Review error messages
3. Contact your development team

### For Design Questions:
1. Refer to color palette above
2. Check existing patterns in App.js
3. Test on multiple screen sizes

---

## 🔐 FILE PERMISSIONS

Your team needs access to:
- `/app/frontend/src/content.js` - Primary content file
- `/app/frontend/tailwind.config.js` - Colors
- `/app/frontend/src/App.js` - Structure (advanced)

All files are fully editable - no restrictions!

---

## 🚀 DEPLOYMENT

Changes are **automatically deployed** when you save files.

No build process needed - just save and refresh!

---

**You have complete control! Edit anything, anytime. 🎉**
