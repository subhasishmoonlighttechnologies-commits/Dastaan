/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Pastel, poppy, fresh color palette
        'brand-coral': '#FF6B6B',        // Poppy coral/salmon pink
        'brand-peach': '#FFE5D9',        // Light peachy background
        'brand-mint': '#4ECDC4',         // Fresh mint/teal
        'brand-lavender': '#A8DADC',     // Soft lavender blue
        'brand-cream': '#FEF9F3',        // Warm cream
        'brand-yellow': '#FFD93D',       // Bright sunny yellow
        'brand-pink': '#FFB6C1',         // Soft pink
        'brand-charcoal': '#2D3142',     // Dark text color
        'brand-sage': '#B8E6B8',         // Pastel sage green
      },
      fontFamily: {
        'serif': ['Georgia', 'Cambria', 'Times New Roman', 'Times', 'serif'],
      },
      animation: {
        'marquee': 'marquee 30s linear infinite',
      },
      keyframes: {
        marquee: {
          '0%': { transform: 'translateX(0%)' },
          '100%': { transform: 'translateX(-50%)' },
        },
      },
    },
  },
  plugins: [],
};
